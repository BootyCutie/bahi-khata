BAHI KHATA - MOBILE WEB APP

Files:
- index.html: the app
- manifest.webmanifest and sw.js: install/offline support when hosted over HTTPS

Use:
1. Extract ZIP.
2. Open index.html in a mobile browser to use it.
3. For installable PWA/offline use, upload all three files to an HTTPS hosting service, then open the URL in Chrome and choose Install app / Add to Home screen.

Features:
- Left panel Income / Debit, right panel Expense / Credit
- Date-wise entries
- Opening balance
- Automatic totals and closing balance
- Delete entry using ×
- Print report and download CSV
- Entries saved in this browser on this device (localStorage)

Important:
Data is stored locally in the browser. It does not automatically sync to another phone or browser. Download CSV backup regularly.
